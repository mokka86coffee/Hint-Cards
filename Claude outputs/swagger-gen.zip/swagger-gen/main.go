// swagger-gen — собирает openapi.yaml из комментариев в исходниках бэкенда.
//
// Обходит все файлы с расширением FileExt в папке -dir (рекурсивно),
// находит блоки комментариев с @route и @schema и пишет спецификацию в -out.
// Формат комментариев — в документе «Задание для бэкенда: описание API
// в комментариях для автогенерации Swagger».
//
// Сборка под Windows 64: GOOS=windows GOARCH=amd64 go build -o swagger-gen.exe .
package main

import (
	"flag"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

// FileExt — расширение файлов бэкенда, в которых ищем комментарии.
const FileExt = ".abc"

// Папки, в которые не заходим.
var skipDirs = map[string]bool{".git": true, "node_modules": true, ".idea": true, ".vscode": true}

func main() {
	dir := flag.String("dir", ".", "папка с исходниками бэкенда")
	out := flag.String("out", "openapi.yaml", "куда записать спецификацию")
	title := flag.String("title", "API", "название API в Swagger")
	version := flag.String("version", "1.0.0", "версия API в Swagger")
	flag.Parse()
	code := run(*dir, *out, *title, *version)
	pauseIfDoubleClicked()
	os.Exit(code)
}

func run(dir, out, title, version string) int {

	files, err := collectFiles(dir)
	if err != nil {
		fmt.Fprintln(os.Stderr, "ошибка обхода папки:", err)
		return 2
	}
	if len(files) == 0 {
		fmt.Fprintf(os.Stderr, "в %s нет файлов *%s\n", dir, FileExt)
		return 2
	}

	p := NewParser()
	for _, f := range files {
		if err := p.ParseFile(f); err != nil {
			fmt.Fprintln(os.Stderr, "не прочитать", f, ":", err)
			return 2
		}
	}

	spec := p.Build(title, version)

	errorsCount := p.PrintIssues(os.Stderr)
	if err := os.WriteFile(out, []byte(ToYAML(spec)), 0o644); err != nil {
		fmt.Fprintln(os.Stderr, "не записать", out, ":", err)
		return 2
	}
	fmt.Fprintf(os.Stderr, "файлов: %d, эндпоинтов: %d, схем: %d → %s\n",
		len(files), p.EndpointCount(), len(p.schemaOrder), out)
	if errorsCount > 0 {
		fmt.Fprintf(os.Stderr, "ошибок: %d — сборка неуспешна\n", errorsCount)
		return 1
	}
	return 0
}

func collectFiles(root string) ([]string, error) {
	var files []string
	err := filepath.WalkDir(root, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.IsDir() {
			if path != root && skipDirs[d.Name()] {
				return filepath.SkipDir
			}
			return nil
		}
		if strings.EqualFold(filepath.Ext(path), FileExt) {
			files = append(files, path)
		}
		return nil
	})
	sort.Strings(files) // одинаковый порядок на любой машине — одинаковый результат
	return files, err
}
