package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"strings"
)

// OMap — словарь с сохранением порядка ключей, чтобы YAML читался по-человечески.
type OMap struct {
	keys []string
	vals map[string]any
}

func NewOMap() *OMap { return &OMap{vals: map[string]any{}} }

func (m *OMap) Set(k string, v any) *OMap {
	if _, ok := m.vals[k]; !ok {
		m.keys = append(m.keys, k)
	}
	m.vals[k] = v
	return m
}

func (m *OMap) Get(k string) any  { return m.vals[k] }
func (m *OMap) Has(k string) bool { _, ok := m.vals[k]; return ok }
func (m *OMap) Len() int          { return len(m.keys) }

func (m *OMap) Clone() *OMap {
	c := NewOMap()
	for _, k := range m.keys {
		v := m.vals[k]
		if o, ok := v.(*OMap); ok {
			v = o.Clone()
		}
		c.Set(k, v)
	}
	return c
}

// ToYAML пишет YAML без внешних библиотек. Все строки в двойных кавычках
// (JSON-строка — корректная YAML-строка), поэтому экранирование надёжное.
func ToYAML(v any) string {
	var b strings.Builder
	writeNode(&b, v, 0)
	return b.String()
}

func scalar(v any) (string, bool) {
	switch x := v.(type) {
	case string:
		return quote(x), true
	case bool:
		if x {
			return "true", true
		}
		return "false", true
	case int:
		return fmt.Sprint(x), true
	case nil:
		return "null", true
	}
	return "", false
}

func quote(s string) string {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	_ = enc.Encode(s)
	return strings.TrimRight(buf.String(), "\n")
}

func isEmpty(v any) (string, bool) {
	switch x := v.(type) {
	case *OMap:
		if x.Len() == 0 {
			return "{}", true
		}
	case []any:
		if len(x) == 0 {
			return "[]", true
		}
	}
	return "", false
}

func writeNode(b *strings.Builder, v any, indent int) {
	pad := strings.Repeat(" ", indent)
	switch x := v.(type) {
	case *OMap:
		for _, k := range x.keys {
			val := x.vals[k]
			key := k
			if strings.ContainsAny(k, ":#{}[],&*!|>'\"%@`/$ ") || k == "" || isNumeric(k) {
				key = quote(k)
			}
			if s, ok := scalar(val); ok {
				fmt.Fprintf(b, "%s%s: %s\n", pad, key, s)
			} else if e, ok := isEmpty(val); ok {
				fmt.Fprintf(b, "%s%s: %s\n", pad, key, e)
			} else {
				fmt.Fprintf(b, "%s%s:\n", pad, key)
				writeNode(b, val, indent+2)
			}
		}
	case []any:
		for _, item := range x {
			if s, ok := scalar(item); ok {
				fmt.Fprintf(b, "%s- %s\n", pad, s)
			} else if e, ok := isEmpty(item); ok {
				fmt.Fprintf(b, "%s- %s\n", pad, e)
			} else {
				fmt.Fprintf(b, "%s-\n", pad)
				writeNode(b, item, indent+2)
			}
		}
	}
}

// isNumeric: ключ «200» без кавычек YAML прочитает как число, а OpenAPI ждёт строку.
func isNumeric(k string) bool {
	for _, c := range k {
		if c < '0' || c > '9' {
			return false
		}
	}
	return k != ""
}
