module swaggergen

go 1.22
