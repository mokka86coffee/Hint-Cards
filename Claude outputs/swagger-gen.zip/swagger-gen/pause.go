package main

import (
	"bufio"
	"fmt"
	"os"
	"runtime"
)

// pauseIfDoubleClicked: при запуске двойным кликом на Windows консоль закрывается
// сразу после выхода — ждём Enter, чтобы был виден результат.
// Если запустили с аргументами (из консоли или CI) — не ждём.
func pauseIfDoubleClicked() {
	if runtime.GOOS != "windows" || len(os.Args) > 1 {
		return
	}
	fmt.Fprint(os.Stderr, "\nНажмите Enter, чтобы закрыть окно…")
	_, _ = bufio.NewReader(os.Stdin).ReadString('\n')
}
