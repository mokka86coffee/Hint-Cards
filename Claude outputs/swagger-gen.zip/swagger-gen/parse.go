package main

import (
	"bytes"
	"fmt"
	"io"
	"os"
	"regexp"
	"sort"
	"strings"
	"unicode/utf8"
)

// Pos — место в исходнике, для сообщений об ошибках.
type Pos struct {
	File string
	Line int
}

func (p Pos) String() string { return fmt.Sprintf("%s:%d", p.File, p.Line) }

// Issue — ошибка или предупреждение.
type Issue struct {
	Pos Pos
	Msg string
	Err bool
}

// Field — одна строка поля: путь[?]: тип - пояснение.
type Field struct {
	Path     string
	Optional bool
	Type     string
	Desc     string
	Enum     []string
	Pos      Pos
}

// Section — request: или response:.
type Section struct {
	Present bool
	Ref     string // «response: InteractionResponse» — весь раздел одна схема
	Fields  []Field
	Pos     Pos
}

// Endpoint — один метод + URL.
type Endpoint struct {
	Method, URL      string
	Summary, Desc    string
	Tag, OperationID string
	Deprecated       bool
	Ignore           bool
	Req, Resp        Section
	Pos              Pos
}

// isFull — блок с request:/response:, а не просто ссылка (@route + @see).
func (e *Endpoint) isFull() bool { return e.Req.Present || e.Resp.Present }

// Schema — блок @schema.
type Schema struct {
	Name          string
	Desc          string
	VariantOf     string
	Discriminator string
	Extends       string
	ExtendsPos    Pos
	Fields        []Field
	Pos           Pos
}

type nameRef struct {
	Name string
	Pos  Pos
}

// Parser накапливает всё, что нашёл во всех файлах.
type Parser struct {
	endpoints   []*Endpoint
	schemas     map[string]*Schema
	schemaOrder []string
	sees        []nameRef // @see — проверить, что схема где-то объявлена
	typeRefs    []nameRef // ссылки на схемы из типов полей
	issues      []Issue

	uniqueEndpoints int // METHOD+URL без повторов-ссылок, считается в Build
}

func NewParser() *Parser {
	return &Parser{schemas: map[string]*Schema{}}
}

func (p *Parser) errorf(pos Pos, f string, a ...any) {
	p.issues = append(p.issues, Issue{Pos: pos, Msg: fmt.Sprintf(f, a...), Err: true})
}

func (p *Parser) warnf(pos Pos, f string, a ...any) {
	p.issues = append(p.issues, Issue{Pos: pos, Msg: fmt.Sprintf(f, a...)})
}

func (p *Parser) EndpointCount() int { return p.uniqueEndpoints }

// PrintIssues печатает ошибки и предупреждения, возвращает число ошибок.
func (p *Parser) PrintIssues(w io.Writer) int {
	sort.SliceStable(p.issues, func(i, j int) bool {
		a, b := p.issues[i].Pos, p.issues[j].Pos
		if a.File != b.File {
			return a.File < b.File
		}
		return a.Line < b.Line
	})
	n := 0
	for _, is := range p.issues {
		kind := "предупреждение"
		if is.Err {
			kind = "ОШИБКА"
			n++
		}
		fmt.Fprintf(w, "%s: %s: %s\n", is.Pos, kind, is.Msg)
	}
	return n
}

// ---------- чтение файла ----------

// readText читает файл и приводит к UTF-8. Бэкенд на Windows часто хранит
// файлы в Windows-1251: если байты не являются корректным UTF-8 — перекодируем.
func readText(path string) (string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	data = bytes.TrimPrefix(data, []byte{0xEF, 0xBB, 0xBF}) // BOM
	if !utf8.Valid(data) {
		return decodeCP1251(data), nil
	}
	return string(data), nil
}

type cline struct {
	Text string
	Line int
}

// commentLines разбирает файл на блоки комментариев: строки комментария
// подряд, без строк кода и пустых строк между ними.
func commentBlocks(src string) [][]cline {
	var blocks [][]cline
	var cur []cline
	inBlock := false
	flush := func() {
		if len(cur) > 0 {
			blocks = append(blocks, cur)
			cur = nil
		}
	}
	for i, raw := range strings.Split(src, "\n") {
		line := strings.TrimSpace(strings.TrimRight(raw, "\r"))
		text, ok := commentText(line, &inBlock)
		if !ok {
			flush()
			continue
		}
		cur = append(cur, cline{Text: text, Line: i + 1})
	}
	flush()
	return blocks
}

// commentText убирает знаки комментария. ok=false — строка не комментарий.
func commentText(line string, inBlock *bool) (string, bool) {
	if *inBlock {
		if i := strings.Index(line, "*/"); i >= 0 {
			*inBlock = false
			line = line[:i]
		}
		return strings.TrimSpace(strings.TrimPrefix(line, "*")), true
	}
	if strings.HasPrefix(line, "/*") {
		rest := strings.TrimLeft(line[2:], "*")
		if i := strings.Index(rest, "*/"); i >= 0 {
			rest = rest[:i]
		} else {
			*inBlock = true
		}
		return strings.TrimSpace(rest), true
	}
	for _, pre := range []string{"///", "//", "--", "#", "'"} {
		if strings.HasPrefix(line, pre) {
			return strings.TrimSpace(line[len(pre):]), true
		}
	}
	return "", false
}

// ---------- разбор блока ----------

var (
	sectionRe = regexp.MustCompile(`^(request|response)\s*:\s*(.*)$`)
	fieldRe   = regexp.MustCompile(`^([A-Za-z_$][\w$]*(?:\[[\w$]*\])?(?:\.[A-Za-z_$][\w$]*(?:\[[\w$]*\])?)*)(\?)?\s*:\s*(.+)$`)
)

func (p *Parser) ParseFile(path string) error {
	src, err := readText(path)
	if err != nil {
		return err
	}
	for _, b := range commentBlocks(src) {
		p.parseBlock(path, b)
	}
	return nil
}

type route struct {
	Method, URL string
	Pos         Pos
}

func (p *Parser) parseBlock(file string, lines []cline) {
	isAPI := false
	for _, l := range lines {
		if strings.HasPrefix(l.Text, "@route") || strings.HasPrefix(l.Text, "@schema") {
			isAPI = true
			break
		}
	}
	if !isAPI {
		return // обычный комментарий
	}

	var routes []route
	var sch *Schema
	var summary string
	var desc []string
	var tag, opID string
	var deprecated, ignore bool
	var req, resp Section
	state := "head"

	for _, l := range lines {
		pos := Pos{file, l.Line}
		t := l.Text
		if t == "" {
			continue
		}

		if strings.HasPrefix(t, "@") {
			parts := strings.Fields(t)
			name, args := parts[0], parts[1:]
			switch name {
			case "@route":
				if len(args) < 2 {
					p.errorf(pos, "@route: нужно «@route МЕТОД /url», а написано %q", t)
					continue
				}
				// поддерживаем и «@route GET POST /url»: все слова кроме последнего — методы
				url := args[len(args)-1]
				for _, m := range args[:len(args)-1] {
					routes = append(routes, route{strings.ToUpper(m), url, pos})
				}
			case "@schema":
				if len(args) < 1 {
					p.errorf(pos, "@schema без имени")
					continue
				}
				sch = &Schema{Name: args[0], Pos: pos}
			case "@variantOf":
				if sch == nil || len(args) < 1 {
					p.errorf(pos, "@variantOf должен стоять после @schema и содержать имя")
					continue
				}
				sch.VariantOf = args[0]
			case "@discriminator":
				if sch == nil || len(args) < 1 {
					p.errorf(pos, "@discriminator должен стоять после @schema и содержать путь поля")
					continue
				}
				sch.Discriminator = args[0]
			case "@extends":
				if sch == nil || len(args) < 1 {
					p.errorf(pos, "@extends должен стоять после @schema и содержать имя базовой схемы")
					continue
				}
				sch.Extends = args[0]
				sch.ExtendsPos = pos
			case "@see":
				if len(args) < 1 {
					p.errorf(pos, "@see без имени схемы")
					continue
				}
				p.sees = append(p.sees, nameRef{args[0], pos}) // путь после имени — для программиста
			case "@tag":
				tag = strings.Join(args, " ")
			case "@operationId":
				if len(args) > 0 {
					opID = args[0]
				}
			case "@deprecated":
				deprecated = true
			case "@ignore":
				ignore = true
			default:
				p.warnf(pos, "неизвестный тег %s — пропущен", name)
			}
			continue
		}

		if m := sectionRe.FindStringSubmatch(t); m != nil {
			state = m[1]
			sec := &req
			if state == "response" {
				sec = &resp
			}
			sec.Present = true
			sec.Pos = pos
			if ref := strings.TrimSpace(m[2]); ref != "" {
				sec.Ref = ref
				p.noteTypeRefs(ref, pos)
			}
			continue
		}

		switch state {
		case "head":
			// в блоке схемы строки-поля идут без секций
			if sch != nil {
				if f, ok := p.parseField(t, pos); ok {
					sch.Fields = append(sch.Fields, f)
					continue
				}
			}
			if summary == "" {
				summary = t
			} else {
				desc = append(desc, t)
			}
		case "request", "response":
			f, ok := p.parseField(t, pos)
			if !ok {
				p.warnf(pos, "строка не похожа на поле «путь: тип - пояснение», пропущена: %q", t)
				continue
			}
			if state == "request" {
				req.Fields = append(req.Fields, f)
			} else {
				resp.Fields = append(resp.Fields, f)
			}
		}
	}

	if sch != nil {
		if sch.Desc == "" {
			sch.Desc = strings.TrimSpace(strings.Join(append([]string{summary}, desc...), "\n"))
		}
		if old, dup := p.schemas[sch.Name]; dup {
			p.errorf(sch.Pos, "схема %s уже объявлена в %s", sch.Name, old.Pos)
		} else {
			p.schemas[sch.Name] = sch
			p.schemaOrder = append(p.schemaOrder, sch.Name)
		}
	}

	for _, r := range routes {
		p.endpoints = append(p.endpoints, &Endpoint{
			Method: r.Method, URL: r.URL,
			Summary: summary, Desc: strings.Join(desc, "\n"),
			Tag: tag, OperationID: opID,
			Deprecated: deprecated, Ignore: ignore,
			Req: req, Resp: resp, Pos: r.Pos,
		})
	}
}

// parseField разбирает «путь[?]: тип - пояснение» (пояснение может начинаться с enum:).
func (p *Parser) parseField(t string, pos Pos) (Field, bool) {
	m := fieldRe.FindStringSubmatch(t)
	if m == nil {
		return Field{}, false
	}
	f := Field{Path: m[1], Optional: m[2] == "?", Pos: pos}
	rest := m[3]
	typ, desc := rest, ""
	if i := strings.Index(rest, " - "); i >= 0 {
		typ, desc = rest[:i], rest[i+3:]
	}
	f.Type = strings.TrimSpace(typ)
	desc = strings.TrimSpace(desc)
	if strings.HasPrefix(desc, "enum:") {
		e := strings.TrimSpace(strings.TrimPrefix(desc, "enum:"))
		desc = ""
		if i := strings.Index(e, ";"); i >= 0 {
			e, desc = e[:i], strings.TrimSpace(e[i+1:])
		}
		f.Enum = strings.Fields(e)
		if len(f.Enum) == 0 {
			p.warnf(pos, "enum без значений")
		}
	}
	f.Desc = desc
	p.noteTypeRefs(f.Type, pos)
	return f, true
}

var refRe = regexp.MustCompile(`\b([A-Z][A-Za-z0-9_]*)\b`)

// noteTypeRefs запоминает ссылки на схемы (слова с заглавной буквы), чтобы потом проверить.
func (p *Parser) noteTypeRefs(typ string, pos Pos) {
	for _, m := range refRe.FindAllStringSubmatch(typ, -1) {
		p.typeRefs = append(p.typeRefs, nameRef{m[1], pos})
	}
}
