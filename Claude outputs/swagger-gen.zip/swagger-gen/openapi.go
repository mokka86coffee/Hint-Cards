package main

import (
	"regexp"
	"sort"
	"strings"
)

// ---------- типы ----------

var (
	arrayOfRe = regexp.MustCompile(`^array\s+of\s+(.+)$`)
	schemaRe  = regexp.MustCompile(`^[A-Z][A-Za-z0-9_]*$`)
)

func ref(name string) *OMap {
	return NewOMap().Set("$ref", "#/components/schemas/"+name)
}

// typeSchema превращает тип из комментария в схему OpenAPI.
func (p *Parser) typeSchema(t string, pos Pos) *OMap {
	t = strings.TrimSpace(t)

	if strings.Contains(t, "|") {
		var parts []*OMap
		nullable := false
		for _, part := range strings.Split(t, "|") {
			part = strings.TrimSpace(part)
			if strings.EqualFold(part, "null") {
				nullable = true
				continue
			}
			parts = append(parts, p.typeSchema(part, pos))
		}
		var s *OMap
		if len(parts) == 1 {
			s = parts[0]
			if s.Has("$ref") { // рядом с $ref другие ключи игнорируются — оборачиваем
				s = NewOMap().Set("allOf", []any{s})
			}
		} else {
			list := make([]any, len(parts))
			for i, x := range parts {
				list[i] = x
			}
			s = NewOMap().Set("oneOf", list)
		}
		if nullable {
			s.Set("nullable", true)
		}
		return s
	}

	if m := arrayOfRe.FindStringSubmatch(t); m != nil {
		return NewOMap().Set("type", "array").Set("items", p.typeSchema(singular(m[1]), pos))
	}
	if strings.HasSuffix(t, "[]") {
		return NewOMap().Set("type", "array").Set("items", p.typeSchema(strings.TrimSuffix(t, "[]"), pos))
	}

	switch strings.ToLower(t) {
	case "string":
		return NewOMap().Set("type", "string")
	case "integer", "int":
		return NewOMap().Set("type", "integer")
	case "number", "float", "double":
		return NewOMap().Set("type", "number")
	case "boolean", "bool":
		return NewOMap().Set("type", "boolean")
	case "object":
		return NewOMap().Set("type", "object")
	case "any":
		return NewOMap()
	case "date":
		return NewOMap().Set("type", "string").Set("format", "date")
	case "datetime":
		return NewOMap().Set("type", "string").Set("format", "date-time")
	case "array":
		return NewOMap().Set("type", "array").Set("items", NewOMap())
	}
	if schemaRe.MatchString(t) {
		return ref(t)
	}
	p.warnf(pos, "неизвестный тип %q — в Swagger будет «любое значение»", t)
	return NewOMap()
}

// singular: «array of objects» → object, «array of strings» → string.
func singular(t string) string {
	t = strings.TrimSpace(t)
	switch strings.ToLower(t) {
	case "objects":
		return "object"
	case "strings":
		return "string"
	case "integers":
		return "integer"
	case "numbers":
		return "number"
	case "booleans":
		return "boolean"
	}
	return t
}

// ---------- дерево полей ----------

// shape — форма значения: объект с полями, массив, словарь или лист с готовой схемой.
type shape struct {
	kind   string // "" (лист), "object", "array", "dict"
	order  []string
	fields map[string]*field
	elem   *shape // элемент массива / значение словаря
	leaf   *OMap  // схема листа (из типа)
	note   string // описание самого значения (для элемента массива / значения словаря)
}

type field struct {
	optional bool
	desc     string
	enum     []string
	s        *shape
	declared bool // поле было описано своей строкой
}

func newObject() *shape { return &shape{kind: "object", fields: map[string]*field{}} }

func (s *shape) child(name string) *field {
	if s.fields == nil {
		s.fields = map[string]*field{}
	}
	f, ok := s.fields[name]
	if !ok {
		f = &field{s: &shape{}}
		s.fields[name] = f
		s.order = append(s.order, name)
	}
	return f
}

type seg struct {
	name string
	arr  bool // name[]
	dict bool // name[key]
}

func splitPath(path string) []seg {
	var out []seg
	for _, part := range strings.Split(path, ".") {
		s := seg{name: part}
		if i := strings.Index(part, "["); i >= 0 {
			s.name = part[:i]
			if part[i:] == "[]" {
				s.arr = true
			} else {
				s.dict = true
			}
		}
		out = append(out, s)
	}
	return out
}

// buildShape собирает дерево объекта из строк полей.
func (p *Parser) buildShape(fields []Field) *shape {
	root := newObject()
	for _, f := range fields {
		cur := root
		segs := splitPath(f.Path)
		for i, sg := range segs {
			fl := cur.child(sg.name)
			last := i == len(segs)-1
			switch {
			case sg.arr || sg.dict:
				kind := "array"
				if sg.dict {
					kind = "dict"
				}
				fl.s.kind = kind
				if fl.s.elem == nil {
					fl.s.elem = &shape{}
				}
				if last {
					// «items[]: string» или «state[controlId]: any» — тип элемента/значения
					// описание и enum относятся к элементу/значению, а не к самому массиву/словарю
					p.applyType(fl.s.elem, f.Type, f.Pos)
					fl.s.elem.note = f.Desc
					if len(f.Enum) > 0 {
						fl.s.elem.leaf = withEnum(orLeaf(fl.s.elem.leaf), f.Enum)
					}
				} else {
					ensureObject(fl.s.elem)
					cur = fl.s.elem
				}
			case last:
				p.applyType(fl.s, f.Type, f.Pos)
				fl.declared = true
				fl.optional = f.Optional
				fl.desc = f.Desc
				fl.enum = f.Enum
			default:
				ensureObject(fl.s)
				cur = fl.s
			}
		}
	}
	return root
}

func ensureObject(s *shape) {
	if s.kind == "" && s.leaf == nil {
		s.kind = "object"
	}
	if s.kind == "object" && s.fields == nil {
		s.fields = map[string]*field{}
	}
}

// applyType задаёт тип узла, сохраняя вложенные поля, если они уже есть.
func (p *Parser) applyType(s *shape, typ string, pos Pos) {
	low := strings.ToLower(strings.TrimSpace(typ))
	switch {
	case low == "object":
		ensureObject(s)
	case low == "array of objects" || low == "array of object":
		s.kind = "array"
		if s.elem == nil {
			s.elem = newObject()
		}
		ensureObject(s.elem)
	default:
		if len(s.fields) > 0 {
			p.warnf(pos, "у поля уже есть вложенные поля, а тип указан %q — оставляю вложенные поля", typ)
			return
		}
		s.kind = ""
		s.leaf = p.typeSchema(typ, pos)
	}
}

// emit превращает дерево в схему OpenAPI.
func emit(s *shape) *OMap {
	switch s.kind {
	case "object":
		o := NewOMap().Set("type", "object")
		if len(s.order) > 0 {
			props := NewOMap()
			var req []any
			for _, name := range s.order {
				f := s.fields[name]
				props.Set(name, fieldSchema(f))
				if !f.optional {
					req = append(req, name)
				}
			}
			o.Set("properties", props)
			if len(req) > 0 {
				o.Set("required", req)
			}
		}
		return o
	case "array":
		return NewOMap().Set("type", "array").Set("items", emit(orEmpty(s.elem)))
	case "dict":
		return NewOMap().Set("type", "object").Set("additionalProperties", emit(orEmpty(s.elem)))
	}
	var o *OMap
	if s.leaf != nil {
		o = s.leaf.Clone()
	} else {
		o = NewOMap()
	}
	if s.note != "" {
		if o.Has("$ref") {
			o = NewOMap().Set("allOf", []any{o})
		}
		o.Set("description", s.note)
	}
	return o
}

func orLeaf(o *OMap) *OMap {
	if o == nil {
		return NewOMap()
	}
	return o
}

func withEnum(o *OMap, enum []string) *OMap {
	vals := make([]any, len(enum))
	for i, v := range enum {
		vals[i] = v
	}
	return o.Set("enum", vals)
}

func orEmpty(s *shape) *shape {
	if s == nil {
		return &shape{}
	}
	return s
}

func fieldSchema(f *field) *OMap {
	s := emit(f.s)
	if s.Has("$ref") && (f.desc != "" || len(f.enum) > 0) {
		s = NewOMap().Set("allOf", []any{s}) // рядом с $ref описание игнорируется
	}
	if f.desc != "" {
		s.Set("description", f.desc)
	}
	if len(f.enum) > 0 {
		vals := make([]any, len(f.enum))
		for i, v := range f.enum {
			vals[i] = v
		}
		// enum относится к значению: у массива — к его элементам
		if s.Get("type") == "array" {
			if items, ok := s.Get("items").(*OMap); ok {
				items.Set("enum", vals)
			}
		} else {
			s.Set("enum", vals)
		}
	}
	return s
}

func topNames(fields []Field) map[string]Pos {
	out := map[string]Pos{}
	for _, f := range fields {
		name := splitPath(f.Path)[0].name
		if _, ok := out[name]; !ok {
			out[name] = f.Pos
		}
	}
	return out
}

// ---------- сборка спецификации ----------

func (p *Parser) Build(title, version string) *OMap {
	spec := NewOMap().
		Set("openapi", "3.0.3").
		Set("info", NewOMap().Set("title", title).Set("version", version))

	schemas := p.buildSchemas()
	paths := p.buildPaths()

	// все ссылки на схемы должны вести на объявленные схемы
	for _, r := range p.typeRefs {
		if _, ok := p.schemas[r.Name]; !ok {
			p.errorf(r.Pos, "ссылка на схему %s, но @schema %s нигде не объявлена", r.Name, r.Name)
		}
	}
	for _, r := range p.sees {
		if _, ok := p.schemas[r.Name]; !ok {
			p.errorf(r.Pos, "@see %s: схема не объявлена ни в одном файле", r.Name)
		}
	}

	spec.Set("paths", paths)
	if schemas.Len() > 0 {
		spec.Set("components", NewOMap().Set("schemas", schemas))
	}
	return spec
}

func (p *Parser) buildSchemas() *OMap {
	out := NewOMap()
	variants := map[string][]string{}

	for _, name := range p.schemaOrder {
		s := p.schemas[name]
		if s.VariantOf != "" {
			variants[s.VariantOf] = append(variants[s.VariantOf], name)
		}
	}

	for _, name := range p.schemaOrder {
		s := p.schemas[name]

		if vs, isUnion := variants[name]; isUnion {
			if len(s.Fields) > 0 {
				p.warnf(s.Pos, "у объединения %s есть свои поля — они игнорируются, поля пишутся в вариантах", name)
			}
			list := make([]any, len(vs))
			for i, v := range vs {
				list[i] = ref(v)
			}
			o := NewOMap().Set("oneOf", list)
			if s.Desc != "" {
				o.Set("description", s.Desc)
			}
			p.addDiscriminator(o, s, vs)
			out.Set(name, o)
			continue
		}

		own := emit(p.buildShape(s.Fields))
		var o *OMap
		if s.Extends != "" {
			p.typeRefs = append(p.typeRefs, nameRef{s.Extends, s.ExtendsPos})
			p.checkExtends(s)
			o = NewOMap().Set("allOf", []any{ref(s.Extends), own})
		} else {
			o = own
		}
		if s.Desc != "" {
			o.Set("description", s.Desc)
		}
		out.Set(name, o)
	}

	for parent, vs := range variants {
		if _, ok := p.schemas[parent]; !ok {
			p.errorf(p.schemas[vs[0]].Pos, "@variantOf %s: схема-объединение %s не объявлена", parent, parent)
		}
	}
	return out
}

// addDiscriminator: если поле-признак на верхнем уровне — стандартный discriminator OpenAPI,
// если вложенное (resultAction.action) — OpenAPI так не умеет, пишем подсказку и x-discriminator.
func (p *Parser) addDiscriminator(o *OMap, union *Schema, variants []string) {
	if union.Discriminator == "" {
		return
	}
	mapping := NewOMap()
	for _, v := range variants {
		for _, f := range p.schemas[v].Fields {
			if f.Path == union.Discriminator {
				if len(f.Enum) == 1 {
					mapping.Set(f.Enum[0], "#/components/schemas/"+v)
				} else {
					p.warnf(f.Pos, "в варианте %s поле %s должно иметь enum с одним значением", v, f.Path)
				}
			}
		}
	}
	if !strings.Contains(union.Discriminator, ".") && !strings.Contains(union.Discriminator, "[") {
		d := NewOMap().Set("propertyName", union.Discriminator)
		if mapping.Len() > 0 {
			d.Set("mapping", mapping)
		}
		o.Set("discriminator", d)
		return
	}
	o.Set("x-discriminator", NewOMap().Set("path", union.Discriminator).Set("mapping", mapping))
	note := "Вариант определяется полем " + union.Discriminator + "."
	if d, _ := o.Get("description").(string); d != "" {
		note = d + "\n\n" + note
	}
	o.Set("description", note)
}

// checkExtends: расширение может только добавлять поля, не перекрывать поля базы.
func (p *Parser) checkExtends(s *Schema) {
	base := map[string]Pos{}
	seen := map[string]bool{}
	for cur := s.Extends; cur != ""; {
		if seen[cur] {
			p.errorf(s.ExtendsPos, "циклическое @extends через %s", cur)
			return
		}
		seen[cur] = true
		b, ok := p.schemas[cur]
		if !ok {
			return // ошибку «не объявлена» выдаст общая проверка ссылок
		}
		for n, pos := range topNames(b.Fields) {
			if _, ok := base[n]; !ok {
				base[n] = pos
			}
		}
		cur = b.Extends
	}
	for n, pos := range topNames(s.Fields) {
		if bp, ok := base[n]; ok {
			p.errorf(pos, "поле %s уже есть в базовой схеме (%s) — @extends может только добавлять поля", n, bp)
		}
	}
}

var noBody = map[string]bool{"GET": true, "DELETE": true, "HEAD": true, "OPTIONS": true}

func (p *Parser) buildPaths() *OMap {
	paths := NewOMap()
	usedOpID := map[string]bool{}

	// Один METHOD+URL может встречаться в разных файлах. Полное описание
	// (с request:/response:) — одно; остальные блоки (только @route + @see)
	// считаются ссылками и в спецификацию не попадают.
	primary := map[string]*Endpoint{}
	var order []string
	for _, e := range p.endpoints {
		if e.Ignore {
			continue
		}
		key := e.Method + " " + e.URL
		old, ok := primary[key]
		if !ok {
			primary[key] = e
			order = append(order, key)
			continue
		}
		switch {
		case e.isFull() && old.isFull():
			p.errorf(e.Pos, "%s: полное описание (request/response) уже есть в %s — оставьте одно, в остальных местах только @route + @see", key, old.Pos)
		case e.isFull():
			primary[key] = e
		}
	}
	// порядок — по месту полного описания, а не по первой ссылке
	idx := map[*Endpoint]int{}
	for i, e := range p.endpoints {
		idx[e] = i
	}
	sort.SliceStable(order, func(i, j int) bool { return idx[primary[order[i]]] < idx[primary[order[j]]] })
	p.uniqueEndpoints = len(order)
	for _, key := range order {
		if e := primary[key]; !e.isFull() {
			p.warnf(e.Pos, "%s: нигде нет request:/response: — в Swagger будет пустой метод", key)
		}
	}

	for _, key := range order {
		e := primary[key]

		op := NewOMap()
		if e.Summary != "" {
			op.Set("summary", e.Summary)
		}
		if e.Desc != "" {
			op.Set("description", e.Desc)
		}
		segs := strings.Split(strings.Trim(e.URL, "/"), "/")
		tag := e.Tag
		if tag == "" && len(segs) >= 2 {
			tag = segs[len(segs)-2] // предпоследний сегмент URL
		}
		if tag != "" {
			op.Set("tags", []any{tag})
		}
		id := e.OperationID
		if id == "" {
			id = segs[len(segs)-1]
		}
		if usedOpID[id] {
			id = id + "_" + strings.ToLower(e.Method) // одна ручка на GET и POST
		}
		usedOpID[id] = true
		op.Set("operationId", id)
		if e.Deprecated {
			op.Set("deprecated", true)
		}

		if e.Req.Present {
			if noBody[e.Method] {
				op.Set("parameters", p.queryParams(e))
			} else {
				op.Set("requestBody", NewOMap().
					Set("required", true).
					Set("content", jsonContent(p.sectionSchema(e.Req))))
			}
		}

		resp := NewOMap().Set("description", "Успешный ответ")
		if e.Resp.Present {
			resp.Set("content", jsonContent(p.sectionSchema(e.Resp)))
		}
		op.Set("responses", NewOMap().Set("200", resp))

		item, ok := paths.Get(e.URL).(*OMap)
		if !ok {
			item = NewOMap()
			paths.Set(e.URL, item)
		}
		item.Set(strings.ToLower(e.Method), op)
	}
	return paths
}

func (p *Parser) sectionSchema(s Section) *OMap {
	if s.Ref != "" {
		return p.typeSchema(s.Ref, s.Pos)
	}
	return emit(p.buildShape(s.Fields))
}

func jsonContent(schema *OMap) *OMap {
	return NewOMap().Set("application/json", NewOMap().Set("schema", schema))
}

// queryParams: у GET поля request: становятся query-параметрами.
func (p *Parser) queryParams(e *Endpoint) []any {
	if e.Req.Ref != "" {
		// вся схема целиком — один «развёрнутый» параметр: её поля уходят в query
		return []any{NewOMap().
			Set("name", "params").
			Set("in", "query").
			Set("style", "form").
			Set("explode", true).
			Set("schema", p.typeSchema(e.Req.Ref, e.Req.Pos))}
	}
	root := p.buildShape(e.Req.Fields)
	var out []any
	for _, name := range root.order {
		f := root.fields[name]
		param := NewOMap().
			Set("name", name).
			Set("in", "query").
			Set("required", !f.optional)
		if f.desc != "" {
			param.Set("description", f.desc)
		}
		sch := fieldSchema(&field{s: f.s, enum: f.enum})
		if f.s.kind == "object" || f.s.kind == "dict" {
			param.Set("style", "deepObject").Set("explode", true)
		}
		param.Set("schema", sch)
		out = append(out, param)
	}
	return out
}
